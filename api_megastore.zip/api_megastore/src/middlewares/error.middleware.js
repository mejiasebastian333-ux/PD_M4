const notFound = (req, res, next) => {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.status = 404;
  next(error);
};

const errorHandler = (err, req, res, next) => {
  const status = err.status || 500;

  if (err.code === '23505')
    return res.status(409).json({ error: 'There is already a customer with that email address.' });
  if (err.code === '23503')
    return res.status(400).json({ error: 'Invalid reference: The related ID does not exist' });
  if (err.code === '22P02')
    return res.status(400).json({ error: 'Invalid data format' });

  console.error(`[ERROR ${status}]`, err.message);

  res.status(status).json({
    error: status === 500 ? 'Internal Server Error' : err.message,
  });
};

module.exports = { notFound, errorHandler };
