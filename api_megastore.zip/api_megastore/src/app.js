const express = require('express');
const customersRoutes = require('./routes/customers.routes');
const { notFound, errorHandler } = require('./middlewares/error.middleware');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/customers', customersRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
