const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     parseInt(process.env.DB_PORT) || 5432,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

pool.on('error', (err) => {
  console.error('Unexpected error in the PostgreSQL pool:', err.message);
});

const testConnection = async () => {
  try {
    const client = await pool.connect();
    console.log('Successful connection to PostgreSQL');
    client.release();
  } catch (err) {
    console.error('Unable to connect to PostgreSQL:', err.message);
    process.exit(1);
  }
};

module.exports = { pool, testConnection };
