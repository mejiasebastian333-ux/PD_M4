const { pool } = require('../config/db');

const getAll = async () => {
  const { rows } = await pool.query(
    `SELECT customer_id, name, email, address, phone
     FROM customers
     ORDER BY customer_id`
  );
  return rows;
};

const getById = async (id) => {
  const { rows } = await pool.query(
    `SELECT customer_id, name, email, address, phone
     FROM customers
     WHERE customer_id = $1`,
    [id]
  );
  return rows[0] || null;
};

const create = async ({ name, email, address, phone }) => {
  const { rows } = await pool.query(
    `INSERT INTO customers (name, email, address, phone)
     VALUES ($1, $2, $3, $4)
     RETURNING *`,
    [name, email, address, phone]
  );
  return rows[0];
};

const update = async (id, { name, email, address, phone }) => {
  const { rows } = await pool.query(
    `UPDATE customers
     SET name    = COALESCE($1, name),
         email   = COALESCE($2, email),
         address = COALESCE($3, address),
         phone   = COALESCE($4, phone)
     WHERE customer_id = $5
     RETURNING *`,
    [name, email, address, phone, id]
  );
  return rows[0] || null;
};

const remove = async (id) => {
  const { rows } = await pool.query(
    `DELETE FROM customers WHERE customer_id = $1 RETURNING *`,
    [id]
  );
  return rows[0] || null;
};

module.exports = { getAll, getById, create, update, remove };
