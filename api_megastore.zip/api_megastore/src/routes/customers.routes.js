const { Router } = require('express');
const ctrl = require('../controllers/customers.controller');

const router = Router();

router.get('/',                     ctrl.getAll);
router.get('/:id',                  ctrl.getById);
router.get('/:id/purchase-history', ctrl.getPurchaseHistory); // BI
router.post('/',                    ctrl.create);
router.put('/:id',                  ctrl.update);
router.delete('/:id',               ctrl.remove);

module.exports = router;
