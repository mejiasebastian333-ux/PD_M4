const service = require('../services/customers.service');

const getAll = async (req, res, next) => {
  try {
    const data = await service.getAll();
    res.status(200).json({ success: true, count: data.length, data });
  } catch (err) { next(err); }
};

const getById = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id))
      return res.status(400).json({ error: 'The ID must be an integer' });

    const data = await service.getById(id);
    if (!data)
      return res.status(404).json({ error: 'Customer not found' });

    res.status(200).json({ success: true, data });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { name, email, address, phone } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length < 2)
      return res.status(400).json({ error: 'The name field is required and must be at least 2 characters long.' });
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return res.status(400).json({ error: 'Email is required and must be in a valid format' });
    if (!address || typeof address !== 'string')
      return res.status(400).json({ error: 'Address is required' });
    if (!phone || typeof phone !== 'string')
      return res.status(400).json({ error: 'Phone is required' });

    const data = await service.create({
      name:    name.trim(),
      email:   email.trim().toLowerCase(),
      address: address.trim(),
      phone:   phone.trim(),
    });
    res.status(201).json({ success: true, data });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id))
      return res.status(400).json({ error: 'The ID must be an integer' });

    const { name, email, address, phone } = req.body;
    if (!name && !email && !address && !phone)
      return res.status(400).json({ error: 'You must submit at least one field to update' });

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return res.status(400).json({ error: 'email must be in a valid format' });

    const data = await service.update(id, { name, email, address, phone });
    if (!data)
      return res.status(404).json({ error: 'Customer not found' });

    res.status(200).json({ success: true, data });
  } catch (err) { next(err); }
};

const remove = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id))
      return res.status(400).json({ error: 'The ID must be an integer' });

    const data = await service.remove(id);
    if (!data)
      return res.status(404).json({ error: 'Customer not found' });

    res.status(200).json({ success: true, message: 'Client successfully removed', data });
  } catch (err) { next(err); }
};


module.exports = { getAll, getById, create, update, remove };
