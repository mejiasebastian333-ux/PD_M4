require('dotenv').config();

const app = require('./src/app');
const { testConnection } = require('./src/config/db');

const PORT = process.env.PORT || 3000;

const start = async () => {
  await testConnection();

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`\nAvailable endpoints:`);
    console.log(`   GET    /health`);
    console.log(`   GET    /api/customers`);
    console.log(`   GET    /api/customers/:id`);
    console.log(`   GET    /api/customers/:id/purchase-history`);
    console.log(`   POST   /api/customers`);
    console.log(`   PUT    /api/customers/:id`);
    console.log(`   DELETE /api/customers/:id`);
  });
};

start().catch((err) => {
  console.error('Error starting the server:', err.message);
  process.exit(1);
});
