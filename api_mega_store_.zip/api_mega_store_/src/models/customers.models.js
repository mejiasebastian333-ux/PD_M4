import mongoose from "mongoose"

export const customersShema = new mongoose.Shema(
    {
        customer_id: String,
        name: String,
        email: String,
        address: String,
        phone: String
    },
    {
        timestamps: true
    }
)

export const Customer = mongoose.model('Customer', customersShema)