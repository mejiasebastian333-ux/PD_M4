import { Router } from "express";
import { } from

export const customerRoutes = Router();