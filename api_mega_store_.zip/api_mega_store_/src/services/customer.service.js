import { pool } from "../config/database/pgconfig.js";

export const createdCustomer = async (name, email, address, phone) => {

    const query = `INSERT INTO sebastian_mejia_pd.customers (name, email, address, phone)) VALUES ($1, TO_DATE($2, 'DD/MM/YYYY')) RETURNING id, name`;
    const values = [name, birth_date]

    try {

        const response = await pool.query(query, values);
        if (!response.rows[0]) {
            throw Error("No se ha logrado crear el cliente")
        }
        return response;

    } catch (error) {
        console.error(`No se ha podido crear el cliente: ${error}`);
        throw (error);
    }

}